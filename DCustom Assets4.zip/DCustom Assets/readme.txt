=== Dcustom assets ===
Contributors: DannieSoft
Donate link: www.xoftpros.com
Tags: Crocoblock, Jetengine, User, cpt and dynamic funtions
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage dynamic custom funtions and assets.

== Description ==

This plugin provides dynamic funtions to enhance website management

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/dcustom-assets` directory
2. Activate the plugin through the 'Plugins' screen in WordPress


== Changelog ==

= 1.0 =
* Initial release with all three systems integrated